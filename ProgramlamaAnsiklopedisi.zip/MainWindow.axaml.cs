using Avalonia.Controls;
using Avalonia.Interactivity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ProgramlamaAnsiklopedisi;

public class AnsiklopediMaddesi
{
    public string Baslik { get; set; } = string.Empty;
    public string Hafta { get; set; } = string.Empty;
    public string Kategori { get; set; } = string.Empty;
    public string KarmasiklikVeOzet { get; set; } = string.Empty;
    public string KavramsalAnlatim { get; set; } = string.Empty;
    public string GercekHayatAnalojisi { get; set; } = string.Empty;
    public string TeknikMekanizma { get; set; } = string.Empty;
    public string PythonKodu { get; set; } = string.Empty;
    public string KodAciklamasi { get; set; } = string.Empty;
    public string HatalarVeIpuclari { get; set; } = string.Empty;

    [JsonIgnore]
    public bool EkstraMi { get; set; }
}

public partial class MainWindow : Window
{
    private readonly List<AnsiklopediMaddesi> _tumMaddeler = new();
    private readonly ObservableCollection<AnsiklopediMaddesi> _filtrelenmisMaddeler = new();
    private readonly HashSet<string> _silinenVarsayilanBasliklar = new();
    private readonly string _ekstraDosyaYolu = Path.Combine(AppContext.BaseDirectory, "ekstra_maddeler.json");
    private readonly string _silinenDosyaYolu = Path.Combine(AppContext.BaseDirectory, "silinen_maddeler.json");
    private AnsiklopediMaddesi? _silinecekMadde;

    public MainWindow()
    {
        InitializeComponent();
        VerileriYukle();
        FiltreleriDoldur();
        ListeyiGuncelle();
    }

    private void VerileriYukle()
    {
        if (File.Exists(_silinenDosyaYolu))
        {
            try
            {
                string silinenJson = File.ReadAllText(_silinenDosyaYolu);
                var silinenler = JsonSerializer.Deserialize<List<string>>(silinenJson);
                if (silinenler != null)
                {
                    foreach (var baslik in silinenler)
                    {
                        _silinenVarsayilanBasliklar.Add(baslik);
                    }
                }
            }
            catch
            {
                // Silinen kayıt dosyası okunamazsa varsayılanlarla devam edilir.
            }
        }

        var varsayilanlar = AnsiklopediVeriBankasi.VarsayilanMaddeleriGetir()
            .Where(m => !_silinenVarsayilanBasliklar.Contains(m.Baslik));
        _tumMaddeler.AddRange(varsayilanlar);

        if (File.Exists(_ekstraDosyaYolu))
        {
            try
            {
                string json = File.ReadAllText(_ekstraDosyaYolu);
                var kayitli = JsonSerializer.Deserialize<List<AnsiklopediMaddesi>>(json);
                if (kayitli != null)
                {
                    foreach (var madde in kayitli)
                    {
                        madde.EkstraMi = true;
                        _tumMaddeler.Add(madde);
                    }
                }
            }
            catch
            {
                // JSON okuma hatası olursa yerleşik verilerle devam edilir.
            }
        }
    }

    private void EkstraMaddeleriKaydet()
    {
        var ekstraListesi = _tumMaddeler.Where(m => m.EkstraMi).ToList();
        File.WriteAllText(
            _ekstraDosyaYolu,
            JsonSerializer.Serialize(ekstraListesi, new JsonSerializerOptions { WriteIndented = true }));
    }

    private void SilinenVarsayilanlariKaydet()
    {
        File.WriteAllText(
            _silinenDosyaYolu,
            JsonSerializer.Serialize(_silinenVarsayilanBasliklar.ToList(), new JsonSerializerOptions { WriteIndented = true }));
    }

    private void FiltreleriDoldur()
    {
        string? oncekiSecim = HaftaFiltresi.SelectedItem as string;
        var haftalar = new List<string> { "Tüm Haftalar ve Konular" };
        haftalar.AddRange(_tumMaddeler.Select(m => m.Hafta).Distinct());
        HaftaFiltresi.ItemsSource = haftalar;

        if (!string.IsNullOrEmpty(oncekiSecim) && haftalar.Contains(oncekiSecim))
        {
            HaftaFiltresi.SelectedItem = oncekiSecim;
        }
        else
        {
            HaftaFiltresi.SelectedIndex = 0;
        }

        MaddeListesi.ItemsSource = _filtrelenmisMaddeler;
    }

    private void ListeyiGuncelle(int tercihEdilenIndeks = 0)
    {
        string arama = (AramaKutusu.Text ?? string.Empty).Trim().ToLowerInvariant();
        string seciliHafta = HaftaFiltresi.SelectedItem as string ?? "Tüm Haftalar ve Konular";

        var sonuc = _tumMaddeler.Where(m =>
        {
            bool haftaUygun = seciliHafta == "Tüm Haftalar ve Konular" || m.Hafta == seciliHafta;
            if (!haftaUygun) return false;

            if (string.IsNullOrEmpty(arama)) return true;

            return m.Baslik.ToLowerInvariant().Contains(arama)
                || m.Kategori.ToLowerInvariant().Contains(arama)
                || m.Hafta.ToLowerInvariant().Contains(arama)
                || m.KavramsalAnlatim.ToLowerInvariant().Contains(arama)
                || m.GercekHayatAnalojisi.ToLowerInvariant().Contains(arama)
                || m.PythonKodu.ToLowerInvariant().Contains(arama)
                || m.HatalarVeIpuclari.ToLowerInvariant().Contains(arama);
        }).ToList();

        _filtrelenmisMaddeler.Clear();
        foreach (var item in sonuc)
        {
            _filtrelenmisMaddeler.Add(item);
        }

        SayacMetni.Text = $"{_filtrelenmisMaddeler.Count} madde listeleniyor";

        bool maddeVar = _filtrelenmisMaddeler.Count > 0;
        SilBtn.IsEnabled = maddeVar;
        OncekiBtn.IsEnabled = maddeVar;
        SonrakiBtn.IsEnabled = maddeVar;
        KopyalaBtn.IsEnabled = maddeVar;

        if (maddeVar)
        {
            int hedefIndeks = Math.Clamp(tercihEdilenIndeks, 0, _filtrelenmisMaddeler.Count - 1);
            MaddeListesi.SelectedIndex = hedefIndeks;
        }
        else
        {
            DetayAlanlariniTemizle();
        }
    }

    private void DetayAlanlariniTemizle()
    {
        SeciliHaftaEtiketi.Text = "-";
        SeciliKategoriEtiketi.Text = "-";
        SeciliOzetEtiketi.Text = "-";
        DetayBaslik.Text = "Gösterilecek madde bulunamadı";
        DetayKavramsal.Text = "";
        DetayAnaloji.Text = "";
        DetayTeknik.Text = "";
        DetayKod.Text = "";
        DetayKodAciklama.Text = "";
        DetayHatalar.Text = "";
    }

    private void MaddeyiGoster(AnsiklopediMaddesi? madde)
    {
        if (madde == null) return;

        SeciliHaftaEtiketi.Text = madde.Hafta;
        SeciliKategoriEtiketi.Text = madde.Kategori;
        SeciliOzetEtiketi.Text = madde.KarmasiklikVeOzet;
        DetayBaslik.Text = madde.Baslik;
        DetayKavramsal.Text = madde.KavramsalAnlatim;
        DetayAnaloji.Text = madde.GercekHayatAnalojisi;
        DetayTeknik.Text = madde.TeknikMekanizma;
        DetayKod.Text = madde.PythonKodu;
        DetayKodAciklama.Text = madde.KodAciklamasi;
        DetayHatalar.Text = madde.HatalarVeIpuclari;
        KopyalaBtn.Content = "Kodu Kopyala";
        IcerikScroll.Offset = new Avalonia.Vector(0, 0);
    }

    private void AramaKutusu_TextChanged(object? sender, TextChangedEventArgs e) => ListeyiGuncelle();
    private void HaftaFiltresi_SelectionChanged(object? sender, SelectionChangedEventArgs e) => ListeyiGuncelle();

    private void MaddeListesi_SelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (MaddeListesi.SelectedItem is AnsiklopediMaddesi secili)
        {
            MaddeyiGoster(secili);
        }
    }

    private void OncekiBtn_Click(object? sender, RoutedEventArgs e)
    {
        if (_filtrelenmisMaddeler.Count == 0) return;
        int idx = MaddeListesi.SelectedIndex;
        MaddeListesi.SelectedIndex = idx > 0 ? idx - 1 : _filtrelenmisMaddeler.Count - 1;
    }

    private void SonrakiBtn_Click(object? sender, RoutedEventArgs e)
    {
        if (_filtrelenmisMaddeler.Count == 0) return;
        int idx = MaddeListesi.SelectedIndex;
        MaddeListesi.SelectedIndex = (idx + 1) % _filtrelenmisMaddeler.Count;
    }

    private async void KopyalaBtn_Click(object? sender, RoutedEventArgs e)
    {
        var clipboard = TopLevel.GetTopLevel(this)?.Clipboard;
        if (clipboard != null && !string.IsNullOrEmpty(DetayKod.Text))
        {
            await clipboard.SetTextAsync(DetayKod.Text);
            KopyalaBtn.Content = "Kopyalandı ✓";
            await Task.Delay(1500);
            KopyalaBtn.Content = "Kodu Kopyala";
        }
    }

    private void SilBtn_Click(object? sender, RoutedEventArgs e)
    {
        if (MaddeListesi.SelectedItem is not AnsiklopediMaddesi secili) return;

        _silinecekMadde = secili;
        SilinecekBaslikMetni.Text = $"\"{secili.Baslik}\"";
        SilmeOnayPaneli.IsVisible = true;
    }

    private void SilmeIptalBtn_Click(object? sender, RoutedEventArgs e)
    {
        _silinecekMadde = null;
        SilmeOnayPaneli.IsVisible = false;
    }

    private void SilmeOnaylaBtn_Click(object? sender, RoutedEventArgs e)
    {
        if (_silinecekMadde == null) return;

        int mevcutIndeks = MaddeListesi.SelectedIndex;
        _tumMaddeler.Remove(_silinecekMadde);

        if (_silinecekMadde.EkstraMi)
        {
            EkstraMaddeleriKaydet();
        }
        else
        {
            _silinenVarsayilanBasliklar.Add(_silinecekMadde.Baslik);
            SilinenVarsayilanlariKaydet();
        }

        _silinecekMadde = null;
        SilmeOnayPaneli.IsVisible = false;

        FiltreleriDoldur();
        ListeyiGuncelle(mevcutIndeks);
    }

    private void YeniMaddeAcBtn_Click(object? sender, RoutedEventArgs e)
    {
        EklemePaneli.IsVisible = true;
    }

    private void YeniMaddeIptalBtn_Click(object? sender, RoutedEventArgs e)
    {
        EklemePaneli.IsVisible = false;
    }

    private void YeniMaddeKaydetBtn_Click(object? sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(YeniBaslikBox.Text)) return;

        var yeni = new AnsiklopediMaddesi
        {
            Baslik = YeniBaslikBox.Text.Trim(),
            Hafta = string.IsNullOrWhiteSpace(YeniHaftaBox.Text) ? "Ek Not" : YeniHaftaBox.Text.Trim(),
            Kategori = string.IsNullOrWhiteSpace(YeniKategoriBox.Text) ? "Genel" : YeniKategoriBox.Text.Trim(),
            KarmasiklikVeOzet = string.IsNullOrWhiteSpace(YeniOzetBox.Text) ? "Özel Kayıt" : YeniOzetBox.Text.Trim(),
            KavramsalAnlatim = YeniKavramsalBox.Text?.Trim() ?? "",
            GercekHayatAnalojisi = YeniAnalojiBox.Text?.Trim() ?? "",
            TeknikMekanizma = YeniTeknikBox.Text?.Trim() ?? "",
            PythonKodu = YeniKodBox.Text?.Trim() ?? "",
            KodAciklamasi = YeniKodAciklamaBox.Text?.Trim() ?? "",
            HatalarVeIpuclari = YeniHatalarBox.Text?.Trim() ?? "",
            EkstraMi = true
        };

        _tumMaddeler.Add(yeni);
        EkstraMaddeleriKaydet();

        YeniBaslikBox.Text = "";
        YeniHaftaBox.Text = "";
        YeniKategoriBox.Text = "";
        YeniOzetBox.Text = "";
        YeniKavramsalBox.Text = "";
        YeniAnalojiBox.Text = "";
        YeniTeknikBox.Text = "";
        YeniKodBox.Text = "";
        YeniKodAciklamaBox.Text = "";
        YeniHatalarBox.Text = "";

        EklemePaneli.IsVisible = false;
        FiltreleriDoldur();
        ListeyiGuncelle();
        MaddeListesi.SelectedItem = yeni;
    }
}

public static class AnsiklopediVeriBankasi
{
    public static List<AnsiklopediMaddesi> VarsayilanMaddeleriGetir() => new()
    {
        new AnsiklopediMaddesi
        {
            Baslik = "Spagetti Kod, Modüler Tasarım ve DRY Prensibi",
            Hafta = "Hafta 1",
            Kategori = "Kod Mimarisi",
            KarmasiklikVeOzet = "DRY & Tek Sorumluluk (SRP)",
            KavramsalAnlatim = """
                Yazılım geliştirmede 'çalışan kod' yazmak başlangıçtır; asıl mühendislik o kodu sürdürülebilir, okunabilir ve ölçeklenebilir kurmaktır. Tek bir dosya içinde yüzlerce satır boyunca kopyala-yapıştır ile büyüyen yapılara 'Spagetti Kod' denir. Modüler programlama, büyük sistemi her biri tek bir görevi yapan bağımsız fonksiyon ve modüllere ('Lego bloklarına') ayırır. DRY (Don't Repeat Yourself - Kendini Tekrar Etme) prensibi, aynı mantığın birden fazla yere yazılmasını yasaklar.
                """,
            GercekHayatAnalojisi = """
                Spagetti Makarna ve Lego Blokları: Bir tabak spagetti makarnada çatalı bir uca batırıp çektiğinizde tabağın diğer ucundaki makarnalar da hareket eder; spagetti kodda bir satırı değiştirmek alakasız bir yeri bozar. Modüler kod ise Lego blokları gibidir: Her bloğun sınırı bellidir ve biri bozulduğunda sadece o blok değiştirilir.
                """,
            TeknikMekanizma = """
                - Bilişsel Yük (Cognitive Load): İnsan beyni aynı anda sınırlı sayıda değişkeni takip edebilir. 20-30 satırlık fonksiyonlar odaklanmayı kolaylaştırır.
                - Soyutlama (Abstraction): Kullanıcıya sadece arayüz (fonksiyon adı ve parametreler) sunulur, karmaşık iç işleyiş gizlenir.
                - Tek Sorumluluk Prensibi (SRP): Bir fonksiyon yalnızca tek bir iş yapmalıdır (örneğin ortalama hesaplama ve harf notu belirleme ayrı fonksiyonlar olmalıdır).
                """,
            PythonKodu = """
                def ortalama_hesapla(vize, final):
                    return (vize * 0.4) + (final * 0.6)

                def harf_notu_belirle(ortalama):
                    if ortalama >= 85:
                        return "AA"
                    elif ortalama >= 70:
                        return "BB"
                    elif ortalama >= 50:
                        return "CC"
                    return "FF"

                def ogrenci_karnesi_bas(isim, vize, final):
                    ort = ortalama_hesapla(vize, final)
                    harf = harf_notu_belirle(ort)
                    print(f"{isim} -> Ortalama: {ort:.1f} | Harf Notu: {harf}")

                ogrenci_karnesi_bas("Ahmet", 50, 60)
                """,
            KodAciklamasi = """
                1. ortalama_hesapla(): Sadece matematiksel ağırlık hesabını yapar. Vize oranı %30'a düşerse yalnızca bu satır güncellenir.
                2. harf_notu_belirle(): Sadece sayısal ortalamayı harf notuna çevirir.
                3. ogrenci_karnesi_bas(): İki yardımcı fonksiyonu birleştirerek raporlama görevini üstlenir.
                """,
            HatalarVeIpuclari = """
                - Teknik Borç (Technical Debt): Günü kurtarmak için yapılan kopyala-yapıştır işlemleri, kural değiştiğinde 50 farklı yeri tek tek düzeltme zorunluluğu doğurur.
                - Sihirli Sayılar (Magic Numbers): Kodun ortasına doğrudan 5000 veya 0.18 yazmak yerine VERGI_ORANI = 0.18 gibi sabitler tanımlayın.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Parametre vs. Argüman ve Return vs. Print Farkı",
            Hafta = "Hafta 1",
            Kategori = "Fonksiyon Mekaniği",
            KarmasiklikVeOzet = "Veri Akışı & NoneType",
            KavramsalAnlatim = """
                Parametre, fonksiyon tanımlanırken parantez içine yazılan yer tutucu değişkendir; argüman ise fonksiyon çağrılırken gönderilen gerçek veridir. Öte yandan print() yalnızca insan gözü için ekrana metin basar ve bellekte işlenebilir veri bırakmaz (fonksiyon None döndürür). return ise hesaplanan sonucu programın çağrıldığı noktaya teslim ederek zincirleme işlemler yapılmasını sağlar.
                """,
            GercekHayatAnalojisi = """
                ATM Makbuzu vs. Nakit Para: ATM'den bakiye sorduğunuzda ekranda '1000 TL' yazar veya makbuz verir (print); ancak o makbuzu alıp markette harcayamazsınız. ATM'den para çektiğinizde ise makine elinize fiziksel banknot verir (return); onu cüzdanınıza koyar ve başka yerde harcarsınız.
                """,
            TeknikMekanizma = """
                - print() yalnızca standart çıktıya (stdout) karakter gönderir; fonksiyon sonunda örtük olarak 'return None' çalışır.
                - return ifadesi çalıştığı anda fonksiyon sonlanır ve ürettiği nesnenin bellek referansı çağıran ifadeye aktarılır.
                - Veri işleme boru hatlarında (pipeline) bir fonksiyonun çıktısı başka bir fonksiyona girdi olacaksa return zorunludur.
                """,
            PythonKodu = """
                def topla_print(a, b):
                    print(a + b)  # Ekrana yazar, geriye None döndürür

                def topla_return(a, b):
                    return a + b  # Değeri programın akışına teslim eder

                # Doğru zincirleme işlem:
                sonuc = topla_return(5, 3) * 2
                print(f"Return ile işlem sonucu: {sonuc}")  # Çıktı: 16

                # Yanlış kullanım (TypeError üretir):
                # hatali = topla_print(5, 3) * 2  -> NoneType ile int çarpılamaz!
                """,
            KodAciklamasi = """
                - 'a' ve 'b' fonksiyon tanımında birer PARAMETRE'dir.
                - Çağrı anında gönderilen 5 ve 3 değerleri ise ARGÜMAN'dır.
                - topla_return(5, 3) ifadesi 8 tam sayısına dönüşür ve * 2 işlemi sorunsuz çalışır.
                """,
            HatalarVeIpuclari = """
                - TypeError: unsupported operand type(s) for +: 'NoneType' and 'int' hatası alıyorsanız, büyük ihtimalle return yerine print kullanan bir fonksiyonun sonucunu matematiksel işleme sokmuşsunuzdur.
                - Unreachable Code: return satırından hemen sonra yazılan kodlar asla çalıştırılmaz.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Değişken Kapsamı (Scope - LEGB) ve Gölgeleme",
            Hafta = "Hafta 1",
            Kategori = "Bellek ve Kapsam",
            KarmasiklikVeOzet = "LEGB Kuralı & Shadowing",
            KavramsalAnlatim = """
                Python'da her değişkenin yaşadığı ve erişilebildiği bir sınır (Scope) vardır. Python bir değişken adını ararken sırasıyla LEGB kuralını izler: Local (Yerel), Enclosing (Kapsayan), Global (Modül Geneli) ve Built-in (Yerleşik). Fonksiyon içinde tanımlanan değişkenler yereldir; fonksiyon bittiğinde bellekten silinirler.
                """,
            GercekHayatAnalojisi = """
                Ev ve Yatak Odaları: Global alan evin salonundaki ortak televizyon gibidir; mutfaktaki de yatak odasındaki de onu görebilir. Fonksiyonlar ise kapısı kilitli yatak odalarıdır; odanın içindeki çekmecede ne olduğunu salondakiler göremez.
                """,
            TeknikMekanizma = """
                - Gölgeleme (Shadowing): Global alanda x = 10 varken fonksiyon içinde x = 5 tanımlanırsa, fonksiyon içinde yerel x geçerli olur; dışarıdaki global x bundan etkilenmez.
                - UnboundLocalError: Fonksiyon içinde global bir değişkene atama (puan = puan + 10) yapmaya çalışırsanız, Python o değişkeni yerel sanır ve henüz tanımlanmadığı için hata fırlatır.
                """,
            PythonKodu = """
                puan = 100  # Global değişken

                def golgeleme_ornegi():
                    puan = 50  # Yerel değişken (Global puanı gölgeler)
                    print(f"Fonksiyon içi puan: {puan}")

                def guvenli_guncelleme(mevcut_puan, artis):
                    return mevcut_puan + artis

                golgeleme_ornegi()               # Çıktı: 50
                print(f"Global puan: {puan}")    # Çıktı: 100 (Değişmedi)
                puan = guvenli_guncelleme(puan, 25)
                print(f"Güncel puan: {puan}")    # Çıktı: 125
                """,
            KodAciklamasi = """
                - golgeleme_ornegi() içindeki 'puan = 50' ataması yeni bir yerel değişken yaratır ve fonksiyon bitince yok olur.
                - 'global' anahtar kelimesi yerine parametreyi alıp return ile döndürmek fonksiyonu saf (pure) ve test edilebilir kılar.
                """,
            HatalarVeIpuclari = """
                - 'global' anahtar kelimesinden kaçının: Büyük projelerde hangi fonksiyonun global değişkeni bozduğunu bulmak imkansızlaşır.
                - Mutable Default Arguments Tuzağı: 'def ekle(eleman, liste=[]):' yazmayın; varsayılan liste program boyunca bellekte tek bir kez oluşturulur ve her çağrıda birikir. Bunun yerine 'liste=None' kullanın.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Sözlükler (Dictionaries) ve İç İçe Veri Modelleme",
            Hafta = "Hafta 1",
            Kategori = "Veri Yapıları",
            KarmasiklikVeOzet = "O(1) Hash Erişimi",
            KavramsalAnlatim = """
                Listeler veriyi sıra numarasıyla (indeks) tutarken, Sözlükler (dict) 'Anahtar-Değer' (Key-Value) çiftleri halinde etiketli olarak saklar. Bir sözlüğün değeri başka bir sözlük veya liste olabilir (Nesting). Bu yapı modern web servislerinin kullandığı JSON formatının birebir karşılığıdır.
                """,
            GercekHayatAnalojisi = """
                Süpermarket Rafları vs. Barkod Sistemi: Listede bir ürünü bulmak için rafları tek tek gezmeniz gerekir. Sözlük ise barkod okuyucu gibidir: Elinizde ürün kodu (Key) varsa, sistem sizi doğrudan o ürünün fiyatına ve stok bilgisine (Value) ışınlar.
                """,
            TeknikMekanizma = """
                - Arka planda Hash Table (Karma Tablosu) veri yapısı çalışır.
                - Veri boyutu 10 da olsa 10 milyon da olsa anahtar üzerinden erişim süresi sabittir: O(1).
                - Sözlük anahtarları değiştirilemez (immutable) tipler olmalıdır (str, int, tuple).
                """,
            PythonKodu = """
                market_envanteri = {
                    "muz": {"fiyat": 40, "stok": 6},
                    "elma": {"fiyat": 20, "stok": 0},
                    "portakal": {"fiyat": 15, "stok": 32}
                }

                def satis_yap(envanter, urun, adet):
                    if urun not in envanter:
                        print("Ürün bulunamadı!")
                        return 0
                    if envanter[urun]["stok"] < adet:
                        print("Yetersiz stok!")
                        return 0
                    envanter[urun]["stok"] -= adet
                    return envanter[urun]["fiyat"] * adet

                tutar = satis_yap(market_envanteri, "muz", 2)
                print(f"Ödenecek Tutar: {tutar} TL | Kalan Stok: {market_envanteri['muz']['stok']}")
                """,
            KodAciklamasi = """
                - İç içe sözlük sayesinde ürün adı tek bir anahtar altında hem fiyatını hem stoğunu taşır.
                - 'if urun not in envanter' kontrolü olası KeyError çökmelerini önler.
                """,
            HatalarVeIpuclari = """
                - KeyError: Olmayan bir anahtara doğrudan envanter["armut"] şeklinde erişmek programı çökertir. Önce 'in' operatörüyle kontrol edin veya envanter.get("armut") kullanın.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Sınıf (Class) ve Nesne (Object) Mimarisi",
            Hafta = "Hafta 2",
            Kategori = "OOP Temelleri",
            KarmasiklikVeOzet = "Soyut Şablon vs. Somut Örnek",
            KavramsalAnlatim = """
                Nesne Yönelimli Programlama (OOP), veriyi (nitelikler/attributes) ve bu veriyi işleyen fonksiyonları (metotlar/methods) tek bir kapsül içinde birleştirir. Sınıf (Class), nesnelerin nasıl üretileceğini tanımlayan soyut bir şablondur; Nesne (Object/Instance) ise bu şablondan bellekte oluşturulmuş, kendi durumuna (state) sahip somut varlıktır.
                """,
            GercekHayatAnalojisi = """
                Mimari Plan (Blueprint) ve Fiziksel Ev: Bir mimarın kağıda çizdiği ev planı Sınıftır; içinde yaşayamazsınız ama tüm kuralları belirler. O plandan inşa edilen yan yana 50 fiziksel ev ise Nesnedir; yapıları aynıdır ama her evin kapı numarası ve duvar rengi farklıdır.
                """,
            TeknikMekanizma = """
                - PEP 8 İsimlendirme: Sınıf isimleri CamelCase (BankaHesabi), metot ve değişken isimleri snake_case (bakiye_goster) yazılır.
                - Örnek Niteliği (Instance Attribute): Her nesneye özeldir (__init__ içinde self ile tanımlanır).
                - Sınıf Niteliği (Class Attribute): Sınıf seviyesinde tanımlanır ve tüm nesneler tarafından ortak paylaşılır.
                """,
            PythonKodu = """
                class Calisan:
                    sirket_adi = "Teknoloji A.Ş."  # Sınıf Niteliği (Ortak)
                    calisan_sayisi = 0

                    def __init__(self, emp_id, ad, maas):
                        self.emp_id = emp_id       # Örnek Niteliği (Kişiye özel)
                        self.ad = ad.title()
                        self.maas = float(maas)
                        Calisan.calisan_sayisi += 1

                    def zam_yap(self, yuzde):
                        if yuzde > 0:
                            self.maas += self.maas * (yuzde / 100)

                c1 = Calisan("E101", "ahmet yılmaz", 50000)
                c2 = Calisan("E102", "ayşe demir", 60000)
                c1.zam_yap(10)
                print(f"{c1.ad} Yeni Maaş: {c1.maas} TL | Toplam Çalışan: {Calisan.calisan_sayisi}")
                """,
            KodAciklamasi = """
                - Calisan sınıfı bir veri tipi şablonudur; c1 ve c2 bu şablondan türetilmiş iki bağımsız nesnedir.
                - c1.zam_yap(10) çağrısı yalnızca c1'in maaşını günceller, c2 bundan etkilenmez.
                """,
            HatalarVeIpuclari = """
                - Mutable Class Attribute Tuzağı: Sınıf tepesinde 'liste = []' tanımlarsanız tüm nesneler aynı listeyi paylaşır. Listeleri mutlaka __init__ içinde 'self.liste = []' olarak oluşturun.
                - Sınıf niteliğini değiştirirken 'c1.sirket_adi = ...' yazmak sınıf niteliğini değiştirmez, o nesneye özel gölge (shadow) bir nitelik yaratır.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "__init__ Yapıcı Metot ve self Referans Mekaniği",
            Hafta = "Hafta 2",
            Kategori = "OOP Temelleri",
            KarmasiklikVeOzet = "Instantiation & Explicit self",
            KavramsalAnlatim = """
                __init__ metodu, bir sınıftan yeni nesne türetildiği (instantiation) anda Python tarafından otomatik çağrılan başlatıcı (initializer) metottur. 'self' parametresi ise o an işlem yapılan nesnenin kendisine (bellekteki adresine) işaret eden zorunlu bir referanstır.
                """,
            GercekHayatAnalojisi = """
                Sınıftaki Öğrenciler: Öğretmen 'Herkes kendi defterine ismini yazsın' dediğinde her öğrenci kendi defterine yazar. Buradaki 'kendi' kelimesi Python'daki 'self'tir. Bellekte 100 kedi nesnesi varsa, miyavla() metodunun hangi kedinin adını ekrana basacağını self belirler.
                """,
            TeknikMekanizma = """
                - Arka Plan Dönüşümü: Siz 'tekir.miyavla()' yazdığınızda Python bunu otomatik olarak 'Kedi.miyavla(tekir)' şekline dönüştürür ve nesneyi ilk argüman olarak gizlice gönderir.
                - Python felsefesi (Explicit is better than implicit) gereği Java/C#'taki gizli 'this' yerine 'self' açıkça yazılır.
                """,
            PythonKodu = """
                class Kedi:
                    def __init__(self, isim, renk):
                        self.isim = isim  # Nesnenin hafızasına kaydet
                        self.renk = renk

                    def kendini_tanit(self):
                        return f"Benim adım {self.isim}, rengim {self.renk}."

                tekir = Kedi("Tekir", "Gri")
                print(tekir.kendini_tanit())
                # Arka planda çalışan eşdeğer çağrı:
                print(Kedi.kendini_tanit(tekir))
                """,
            KodAciklamasi = """
                - __init__ içindeki 'self.isim = isim' satırı, dışarıdan geçici gelen parametre değerini nesnenin kalıcı belleğine bağlar.
                - kendini_tanit() metodunda 'isim' yerine 'self.isim' kullanılması zorunludur.
                """,
            HatalarVeIpuclari = """
                - TypeError: takes 0 positional arguments but 1 was given -> Metot tanımında parantez içine 'self' yazmayı unuttuğunuzda Python nesneyi göndermeye çalışır ve bu hata oluşur.
                - NameError: name 'isim' is not defined -> Metot içinde niteliklere erişirken 'self.' önekini unuttuğunuzda oluşur.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Stack & Heap Bellek Düzeni, Referanslar ve CRC Kartları",
            Hafta = "Hafta 2",
            Kategori = "OOP Tasarım",
            KarmasiklikVeOzet = "Aliasing & Mimari Tasarım",
            KavramsalAnlatim = """
                Python'da değişkenler nesnelerin kendisini tutan kutular değil, Heap bellekte yaşayan nesnelerin adresini gösteren etiketlerdir (referans). Kod yazmaya başlamadan önce sınıfların görevlerini ve işbirliklerini planlamak için CRC (Class-Responsibility-Collaboration) kartları kullanılır.
                """,
            GercekHayatAnalojisi = """
                Post-it Etiketler ve CRC Rol Oyunu: Aynı fiziksel kutuya 'kedi1' ve 'kedi2' adında iki etiket yapıştırırsanız (kedi2 = kedi1), birinden kutunun içini değiştirdiğinizde diğeri de değişmiş görür. CRC kartları ise sahneye çıkmadan önce oyunculara (sınıflara) repliklerini dağıtmaktır.
                """,
            TeknikMekanizma = """
                - Stack (Yığın): Fonksiyon çağrılarının ve değişken etiketlerinin (referansların) durduğu hızlı bellek alanıdır.
                - Heap: Nesnelerin (Kedi, Liste, Sözlük) fiziksel verilerinin tutulduğu geniş bellek alanıdır.
                - CRC Kartı 3 Bölümden Oluşur: Sınıf Adı, Sorumluluklar (veri + metot) ve İşbirlikçiler (yardım alınan diğer sınıflar).
                """,
            PythonKodu = """
                import copy

                class Oyuncu:
                    def __init__(self, ad, envanter):
                        self.ad = ad
                        self.envanter = envanter

                o1 = Oyuncu("Yunus", ["Kılıç", "Kalkan"])
                o2 = o1                 # Aliasing (Aynı nesneye ikinci etiket)
                o3 = copy.deepcopy(o1)  # Tam bağımsız derin kopya

                o2.envanter.append("İksir")
                print("o1 envanter:", o1.envanter)  # ['Kılıç', 'Kalkan', 'İksir']
                print("o3 envanter:", o3.envanter)  # ['Kılıç', 'Kalkan']
                """,
            KodAciklamasi = """
                - 'o2 = o1' ataması yeni bir Oyuncu nesnesi yaratmaz; o1 ile aynı bellek adresini paylaşır.
                - 'copy.deepcopy(o1)' ise içindeki liste dahil tamamen bağımsız bir kopya oluşturur.
                """,
            HatalarVeIpuclari = """
                - Basit veri taşıma için boş metotlu sınıflar yazmak (Over-Engineering) yerine sözlük veya @dataclass tercih edin.
                - Bir sınıfa ona ait olmayan sorumluluklar yüklemeyin (örneğin ATM sınıfı bakiyeyi tutmamalı, BankaHesabi sınıfıyla işbirliği yapmalıdır).
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Kapsülleme (Encapsulation) ve Erişim Belirleyiciler",
            Hafta = "Hafta 3",
            Kategori = "OOP Güvenlik",
            KarmasiklikVeOzet = "Public / _Protected / __Private",
            KavramsalAnlatim = """
                Kapsülleme, sınıfın iç verilerini ve karmaşık iş mantığını dış dünyanın kontrolsüz müdahalelerinden koruma ve yalnızca izin verilen arayüzler (metotlar) üzerinden erişim sağlama ilkesidir. Python erişim denetimini anahtar kelimelerle değil, alt çizgi (_) isimlendirme kurallarıyla yönetir.
                """,
            GercekHayatAnalojisi = """
                İlaç Kapsülü ve Otomobil Kaputu: İlaç kapsülünün dış kabuğu (Public API) hastanın ilacı kolayca yutmasını sağlar; içindeki kimyasal tozlar (Private Data) dış etkenlerden korunur. Otomobilde sürücü sadece direksiyon ve pedallara basar; motorun enjeksiyon sistemine doğrudan müdahale edemez.
                """,
            TeknikMekanizma = """
                - Public (isim): Her yerden doğrudan erişilebilir.
                - Protected (_isim): Tek alt çizgi 'Bu iç değişkendir, dışarıdan dokunma' uyarısıdır (Centilmenlik Anlaşması).
                - Private (__isim): Çift alt çizgi Python'da 'Name Mangling' (İsim Değiştirme) mekanizmasını tetikler ve değişken adı arka planda '_SinifAdi__isim' haline dönüştürülür.
                """,
            PythonKodu = """
                class GizliKasa:
                    def __init__(self, pin):
                        self.__pin = pin           # Private (Name Mangling uygulanır)
                        self.__icerik = "Gizli Belge"
                        self.__hatali_deneme = 0

                    def icerigi_gor(self, girilen_pin):
                        if self.__hatali_deneme >= 3:
                            return "KASA BLOKE EDİLDİ!"
                        if girilen_pin == self.__pin:
                            self.__hatali_deneme = 0
                            return f"İçerik: {self.__icerik}"
                        self.__hatali_deneme += 1
                        return "Hatalı PIN!"

                kasa = GizliKasa(1234)
                print(kasa.icerigi_gor(9999))  # Hatalı PIN!
                print(kasa.icerigi_gor(1234))  # İçerik: Gizli Belge
                """,
            KodAciklamasi = """
                - '__pin' ve '__hatali_deneme' dışarıdan 'kasa.__pin' şeklinde doğrudan okunamaz (AttributeError verir).
                - Kullanıcı kasa içeriğine yalnızca kuralları denetleyen 'icerigi_gor()' arayüzü üzerinden ulaşabilir.
                """,
            HatalarVeIpuclari = """
                - Private değişkenleri kriptografik güvenlik sanmayın: '_SinifAdi__degisken' adıyla teknik olarak hala erişilebilir. Kapsülleme hackerlara karşı değil, yazılımcı hatalarına (bug) karşı bir kalkandır.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "@property Dekoratörü ve Veri Sızıntısını Önleme",
            Hafta = "Hafta 3",
            Kategori = "OOP Pythonic",
            KarmasiklikVeOzet = "Getter / Setter & Defensive Copy",
            KavramsalAnlatim = """
                Python'da Java tarzı get_maas() / set_maas() metotları yerine @property dekoratörü kullanılır. Bu sayede dışarıdan bakıldığında basit bir değişken ataması yapılıyormuş gibi görünürken arka planda doğrulama (validation) kuralları çalıştırılır. Ayrıca özel listeleri döndürürken orijinal referans yerine kopya döndürülerek veri sızıntısı önlenir.
                """,
            GercekHayatAnalojisi = """
                Akıllı Güvenlik Kapısı ve Fotokopi: @property görünmez bir güvenlik sensörüdür; siz kapıdan normal yürüyormuş gibi geçersiniz (urun.fiyat = -50) ama arka planda sensör geçersiz değeri yakalayıp engeller. Banka işlem geçmişini isteyen birine ise orijinal defter değil, fotokopisi ([:]) verilir.
                """,
            TeknikMekanizma = """
                - @property: Okuma (Getter) davranışını tanımlar. Tek başına tanımlanırsa değişken 'Salt Okunur' (Read-Only) olur.
                - @isim.setter: Değer atama sırasında doğrulama kurallarını çalıştırır.
                - Defensive Copying: 'return self.__gecmis[:]' ifadesi listenin sığ kopyasını döndürerek dışarıdan .clear() ile orijinal kayıtların silinmesini engeller.
                """,
            PythonKodu = """
                class Urun:
                    def __init__(self, ad, fiyat):
                        self._ad = ad
                        self._fiyat = 0
                        self.fiyat = fiyat  # Setter'ı tetikler
                        self.__loglar = ["Ürün oluşturuldu"]

                    @property
                    def ad(self):  # Salt Okunur (Setter yok)
                        return self._ad.upper()

                    @property
                    def fiyat(self):
                        return self._fiyat

                    @fiyat.setter
                    def fiyat(self, deger):
                        if deger < 0:
                            print("Uyarı: Fiyat negatif olamaz!")
                        else:
                            self._fiyat = deger

                    @property
                    def loglar(self):
                        return self.__loglar[:]  # Kopya döndürerek orijinali koru

                u = Urun("Laptop", 25000)
                u.fiyat = -500  # Uyarı verir, 25000 korunur
                u.loglar.clear()  # Sadece kopyayı siler
                print(u.ad, u.fiyat, len(u.loglar))
                """,
            KodAciklamasi = """
                - 'u.ad' özelliğinin setter'ı olmadığı için 'u.ad = "Yeni"' denemesi AttributeError ile engellenir.
                - 'u.loglar' her çağrıldığında listenin bir kopyasını verir; dış kod orijinal log listesini bozamaz.
                """,
            HatalarVeIpuclari = """
                - Sonsuz Özyineleme Hatası: Setter içinde 'self.fiyat = deger' yazarsanız setter kendi kendini sonsuza dek çağırır ve RecursionError oluşur. Setter içinde mutlaka alt çizgili dahili değişkene ('self._fiyat = deger') atama yapın.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Kalıtım (Inheritance), super() ve Polimorfizm",
            Hafta = "Hafta 4",
            Kategori = "OOP İleri",
            KarmasiklikVeOzet = "Is-A İlişkisi & Overriding",
            KavramsalAnlatim = """
                Kalıtım, bir alt sınıfın (Subclass) bir üst sınıfın (Superclass) nitelik ve metotlarını miras alarak genişletmesini sağlar. Bu ilişki mutlaka 'Is-A' (Bir türüdür) mantığına dayanmalıdır. Polimorfizm (Çok Biçimlilik) ise farklı alt sınıfların aynı metot çağrısına (örneğin ode()) kendi iç mantıklarına göre farklı yanıtlar verebilmesidir.
                """,
            GercekHayatAnalojisi = """
                Biyolojik Evrim ve Türleşme: Tüm kuşlar ortak atadan temel özellikleri (kanat, gaga) miras alır; ancak Serçe ve Kartal uçma davranışını kendi ihtiyaçlarına göre özelleştirir (Override). Yazılımda da ortak özellikler üst sınıfta toplanır, farklar alt sınıflarda ezilir.
                """,
            TeknikMekanizma = """
                - super(): Üst sınıfın yapıcı metodunu (__init__) veya ezilen metodunu dinamik olarak çağırarak kod tekrarını önler.
                - Overriding (Metot Ezme): Alt sınıfta üst sınıfla aynı isimde metot tanımlanarak davranış değiştirilir.
                - Python'da her sınıf örtük olarak 'object' sınıfından türer ve __str__, __eq__ gibi temel metotları miras alır.
                """,
            PythonKodu = """
                class Urun:
                    def __init__(self, isim, ham_fiyat):
                        self.isim = isim
                        self.ham_fiyat = ham_fiyat

                    def vergi_hesapla(self):
                        return self.ham_fiyat * 0.20  # Temel %20 KDV

                class Gida(Urun):
                    def vergi_hesapla(self):
                        return self.ham_fiyat * 0.01  # Tam Override (%1 KDV)

                class Elektronik(Urun):
                    def vergi_hesapla(self):
                        temel_kdv = super().vergi_hesapla()  # Üst sınıfı genişlet
                        otv = self.ham_fiyat * 0.10
                        return temel_kdv + otv

                sepet = [Gida("Ekmek", 10), Elektronik("Telefon", 10000)]
                for u in sepet:
                    print(f"{u.isim} Vergisi: {u.vergi_hesapla()} TL")
                """,
            KodAciklamasi = """
                - Gida sınıfı vergi_hesapla() metodunu tamamen kendi kuralıyla ezer.
                - Elektronik sınıfı super().vergi_hesapla() ile temel KDV'yi alıp üzerine ÖTV ekler.
                - Döngü içinde hangi ürün tipi olduğu sorulmadan aynı metot polimorfik olarak çalıştırılır.
                """,
            HatalarVeIpuclari = """
                - Alt sınıfta __init__ tanımlayıp super().__init__() çağırmayı unutursanız, üst sınıfın nitelikleri hiç oluşturulmaz ve AttributeError alırsınız.
                - Liskov Yerine Geçme Prensibi (LSP): Uçan kuşlar sınıfına Penguen ekleyip uc() metodunda hata fırlatmak tasarım hatasıdır.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Çoklu Kalıtım (MRO), Mixin Sınıfları ve Kompozisyon",
            Hafta = "Hafta 4",
            Kategori = "OOP Mimari",
            KarmasiklikVeOzet = "C3 Linearization & Has-A",
            KavramsalAnlatim = """
                Çoklu kalıtımda aynı metot birden fazla ebeveynde bulunuyorsa (Elmas Problemi), Python hangi sırayla arama yapacağını C3 Linearization algoritması ile oluşturduğu MRO (Method Resolution Order) listesiyle çözer. Yetenek kazandırmak için küçük 'Mixin' sınıfları kullanılır; ancak genel mimaride sıkı bağlı kalıtım yerine esnek 'Kompozisyon' (Has-A) tercih edilir.
                """,
            GercekHayatAnalojisi = """
                Araba bir Motordur vs. Araba Motora Sahiptir: Araba bir araçtır (Is-A -> Kalıtım); ancak araba bir motor değildir, motora sahiptir (Has-A -> Kompozisyon). Kompozisyon sayesinde arabanın motorunu çalışma zamanında kolayca değiştirebilirsiniz.
                """,
            TeknikMekanizma = """
                - MRO Kuralı (Sinif.mro()): Çocuk ebeveynden önce gelir; ebeveynler soldan sağa taranır.
                - Mixin Sınıfları: Durum (__init__) tutmayan, yalnızca ek bir yetenek (örneğin to_json()) sağlayan eklenti sınıflardır.
                - Kompozisyon: Bir sınıfın başka bir sınıf nesnesini kendi içinde nitelik olarak barındırmasıdır.
                """,
            PythonKodu = """
                import json

                class JsonMixin:
                    def to_json(self):
                        return json.dumps(self.__dict__, ensure_ascii=False)

                class AkademikMixin:
                    def ders_ver(self):
                        return f"{self.ad} ders anlatıyor."

                class IdariMixin:
                    def butce_onayla(self):
                        return f"{self.ad} bütçeyi onayladı."

                class Dekan(JsonMixin, AkademikMixin, IdariMixin):
                    def __init__(self, ad):
                        self.ad = ad

                dekan = Dekan("Prof. Dr. Ayşe Yılmaz")
                print(dekan.ders_ver())
                print(dekan.to_json())
                print("MRO Sırası:", [c.__name__ for c in Dekan.mro()])
                """,
            KodAciklamasi = """
                - Dekan sınıfı hem akademik hem idari yetenekleri hem de JSON dönüşümünü Mixin sınıflarından temizce birleştirir.
                - Dekan.mro() metodu Python'un nitelik arama sırasını ekrana basar.
                """,
            HatalarVeIpuclari = """
                - Anti-Pattern: 'class Yigin(list):' şeklinde listeden kalıtım almak yanlıştır; çünkü kullanıcı yığının ortasından insert/remove yapabilir. Bunun yerine Yigin içinde 'self._veri = []' tutarak Kompozisyon kullanın.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Dinamik Polimorfizm, Duck Typing ve Strategy Deseni",
            Hafta = "Hafta 5",
            Kategori = "OOP İleri Tasarım",
            KarmasiklikVeOzet = "Late Binding & Strategy Pattern",
            KavramsalAnlatim = """
                Polimorfizm (Çok Biçimlilik), farklı nesnelerin aynı metot çağrısını (mesajı) alıp kendi iç doğalarına uygun farklı davranışlar sergilemesidir. Python'da dinamik polimorfizm çalışma zamanında (Run-Time) gerçekleşir ve sistemi devasa if-elif bloklarından kurtararak Open/Closed (Gelişime açık, değişime kapalı) prensibini sağlar. Strategy Pattern ise algoritmaları birbirinden izole sınıflara ayırıp çalışma anında değiştirmeyi mümkün kılar.
                """,
            GercekHayatAnalojisi = """
                Evrensel Kumandadaki 'Oynat' (Play) Tuşu: Masanızda DVD oynatıcı, MP3 çalar ve Akıllı TV duruyor. Hepsinin donanımı ve çalışma prensibi tamamen farklıdır; ama siz sadece tek bir üçgen 'Oynat' tuşuna basarsınız. DVD diski döndürür, MP3 dijital sesi çözer, TV ise internetten yayın başlatır.
                """,
            TeknikMekanizma = """
                - Statik vs. Dinamik Polimorfizm: Statik polimorfizm derleme zamanında (Overloading), dinamik polimorfizm ise çalışma zamanında (Overriding / Late Binding / Dynamic Dispatch) çözülür.
                - Duck Typing (Ördek Tiplemesi): 'Bir şey ördek gibi yürüyorsa ve vaklıyorsa o bir ördektir.' Python ortak ata sınıf olmasa bile çağrılan metodun nesnede bulunmasını yeterli görür.
                - Gevşek Bağlılık (Loose Coupling): Sepet sınıfı somut ödeme yöntemlerine değil, soyut OdemeStratejisi arayüzüne bağımlıdır.
                """,
            PythonKodu = """
                class KrediKartiOdeme:
                    def __init__(self, kart_son_4):
                        self.kart_son_4 = kart_son_4

                    def ode(self, tutar):
                        print(f"Kredi Kartı (**** {self.kart_son_4}) ile {tutar} TL çekildi.")
                        return True

                class KriptoOdeme:
                    def __init__(self, cuzdan):
                        self.cuzdan = cuzdan

                    def ode(self, tutar):
                        print(f"Blockchain ({self.cuzdan[:8]}...) üzerinden {tutar} TL transfer edildi.")
                        return True

                class Sepet:
                    def __init__(self):
                        self.toplam = 0
                        self.strateji = None

                    def strateji_sec(self, odeme_yontemi):
                        self.strateji = odeme_yontemi

                    def odemeyi_tamamla(self):
                        if self.strateji:
                            self.strateji.ode(self.toplam)

                sepet = Sepet()
                sepet.toplam = 1500
                sepet.strateji_sec(KrediKartiOdeme("3456"))
                sepet.odemeyi_tamamla()

                sepet.strateji_sec(KriptoOdeme("bc1qxy2kgdygjrsqtzq2n"))
                sepet.odemeyi_tamamla()
                """,
            KodAciklamasi = """
                - Sepet sınıfı içinde 'if odeme_tipi == "kredi_karti"' gibi hiçbir tür kontrolü bulunmaz.
                - Yarın sisteme 'KapidaOdeme' sınıfı eklendiğinde Sepet sınıfının tek bir satırı bile değiştirilmeden çalışmaya devam eder.
                """,
            HatalarVeIpuclari = """
                - isinstance() Bataklığı: Bir fonksiyon içinde her sınıf için 'if isinstance(x, TipA): ... elif isinstance(x, TipB): ...' yazıyorsanız polimorfizmi öldürüyorsunuz demektir.
                - Python'da aynı sınıf içinde aynı isimle iki metot tanımlarsanız (Overloading denemesi), ikinci tanım birincisini ezer.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Soyutlama (Abstraction), ABC Modülü ve @abstractmethod",
            Hafta = "Hafta 5",
            Kategori = "OOP Mimari",
            KarmasiklikVeOzet = "abc Modülü & Sözleşme Tasarımı",
            KavramsalAnlatim = """
                Soyutlama (Abstraction), bir sistemin 'NE' yapacağının kurallarını ve arayüzünü belirleyip, 'NASIL' yapılacağının karmaşık uygulama detaylarını gizleme sanatıdır. Python'da soyut temel sınıflar yerleşik 'abc' (Abstract Base Classes) modülü ve '@abstractmethod' dekoratörü ile tanımlanır.
                """,
            GercekHayatAnalojisi = """
                Mimar ve Müteahhit Sözleşmesi (Blueprint) & Priz-Fiş: Mimar planda 'Burada 2x1 metrelik yangın kapısı olacak' der (Arayüz); menteşenin hangi tornavidayla takılacağını müteahhite bırakır. Duvardaki priz ise standart voltaj ve iki delik kuralını sunar; fişe takılan cihazın televizyon mu süpürge mi olduğuyla ilgilenmez.
                """,
            TeknikMekanizma = """
                - Örneklenemezlik (Non-instantiability): ABC sınıfından türeyen ve içinde en az bir @abstractmethod barındıran sınıftan doğrudan nesne üretilemez (TypeError fırlatır).
                - Uygulama Zorunluluğu (Enforcement): Soyut sınıfı miras alan her somut alt sınıf, tüm soyut metotları ezmek (override) zorundadır.
                - Soyut sınıflar, soyut metotların yanında tüm alt sınıfların miras alacağı normal (somut) metotlar da barındırabilir.
                """,
            PythonKodu = """
                from abc import ABC, abstractmethod

                class MedyaDosyasi(ABC):
                    def __init__(self, dosya_adi):
                        self.dosya_adi = dosya_adi

                    @abstractmethod
                    def oynat(self):
                        pass

                    @abstractmethod
                    def durdur(self):
                        pass

                    def bilgi_ver(self):  # Ortak somut metot
                        return f"Dosya: {self.dosya_adi}"

                class MP3Dosyasi(MedyaDosyasi):
                    def oynat(self):
                        return f"{self.dosya_adi} MP3 codec ile çalınıyor..."

                    def durdur(self):
                        return f"{self.dosya_adi} durduruldu."

                # m = MedyaDosyasi("test") -> TypeError: Can't instantiate abstract class!
                sarki = MP3Dosyasi("sarki.mp3")
                print(sarki.bilgi_ver(), "->", sarki.oynat())
                """,
            KodAciklamasi = """
                - MedyaDosyasi sınıfı bir mimari sözleşmedir; oynat() ve durdur() metotlarının varlığını garanti eder.
                - MP3Dosyasi bu iki soyut metodu tanımladığı için somutlaşabilir ve nesne üretilebilir.
                """,
            HatalarVeIpuclari = """
                - Alt sınıfta soyut metotlardan yalnızca birini bile yazmayı unutursanız, Python o alt sınıfı da soyut kabul eder ve nesne üretirken 'TypeError: Can't instantiate abstract class ... with abstract method ...' hatası verir.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "İstisna Yönetimi (try-except-else-finally) ve Hiyerarşi",
            Hafta = "Hafta 6",
            Kategori = "Savunmacı Kodlama",
            KarmasiklikVeOzet = "try / except / else / finally",
            KavramsalAnlatim = """
                Yazılım hataları üç gruba ayrılır: Sözdizimi Hataları (SyntaxError), Mantıksal Hatalar ve Çalışma Zamanı İstisnaları (Runtime Exceptions). İstisna yönetimi, programın beklenmedik girdiler, dosya eksiklikleri veya ağ kesintileri karşısında kontrolsüzce çökmesini önleyip kararlı (robust) kalmasını sağlayan hayatta kalma mekanizmasıdır.
                """,
            GercekHayatAnalojisi = """
                Ariane 5 Roketi (1996) ve USS Yorktown Kruvazörü (1997): Ariane 5'te 64-bitlik yatay hız verisi 16-bit tamsayıya dönüştürülürken taşma (OverflowError) yakalanmadığı için roket 37. saniyede infilak etti. USS Yorktown savaş gemisinde ise veritabanına '0' girilmesiyle oluşan ZeroDivisionError yakalanmadığı için tüm gemi motorları durdu.
                """,
            TeknikMekanizma = """
                - try: Yalnızca hata fırlatma ihtimali olan en dar kod parçası buraya konmalıdır.
                - else: Sadece try bloğu hatasız tamamlanırsa çalışır; try kapsamını dar tutarak 'Accidental Catching' (yanlışlıkla başka hatayı yakalama) riskini önler.
                - finally: Hata olsa da olmasa da, return yapılsa da mutlaka çalışır; dosya ve bağlantı kapatma (cleanup) için kullanılır.
                - İstisna Hiyerarşisi: BaseException en tepededir (SystemExit ve KeyboardInterrupt burada yer alır). Kullanıcı hataları Exception altındadır.
                """,
            PythonKodu = """
                def guvenli_bolme_ve_oku(dosya_adi, bolen):
                    dosya = None
                    try:
                        sonuc = 100 / bolen
                        dosya = open(dosya_adi, "r", encoding="utf-8")
                    except ZeroDivisionError:
                        print("Hata: Bölen sıfır olamaz!")
                    except FileNotFoundError:
                        print(f"Hata: '{dosya_adi}' bulunamadı.")
                    else:
                        # Sadece try hatasız biterse burası çalışır
                        icerik = dosya.read()
                        print(f"Sonuç: {sonuc} | Okunan karakter: {len(icerik)}")
                    finally:
                        if dosya:
                            dosya.close()
                            print("Dosya kaynağı güvenle kapatıldı.")

                guvenli_bolme_ve_oku("olmayan.txt", 5)
                """,
            KodAciklamasi = """
                - Spesifik hata türleri (ZeroDivisionError, FileNotFoundError) ayrı ayrı yakalanarak net geri bildirim verilir.
                - dosya.read() işlemi else bloğuna alınarak okuma sırasında oluşabilecek farklı bir hatanın 'Dosya bulunamadı' sanılması önlenir.
                """,
            HatalarVeIpuclari = """
                - Çıplak 'except:' veya 'except BaseException:' Kullanmayın (Diabolical Anti-Pattern): Bu bloklar CTRL+C (KeyboardInterrupt) ve çıkış sinyallerini de yutar; programınızı kapatılamaz 'zombi' moda sokar. Genel yakalama için daima 'except Exception:' kullanın.
                - Traceback bilgisini asla ham haliyle son kullanıcıya göstermeyin; dosya yolları hackerlar için istihbarat kaynağıdır.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Savunmacı Paradigmalar (LBYL vs. EAFP), raise ve Loglama",
            Hafta = "Hafta 6",
            Kategori = "Kararlılık ve Loglama",
            KarmasiklikVeOzet = "EAFP vs. LBYL & logging",
            KavramsalAnlatim = """
                Hata yönetiminde iki temel felsefe vardır: LBYL (Look Before You Leap — Atlamadan Önce Bak) işlem öncesi her koşulu if ile denetlerken, Python'un benimsediği EAFP (Easier to Ask for Forgiveness than Permission — İzin Almaktansa Af Dilemek) işlemi doğrudan dener ve hata oluşursa yakalar. Ayrıca profesyonel sistemlerde print() yerine seviyeli loglama (logging) ve özel istisna sınıfları kullanılır.
                """,
            GercekHayatAnalojisi = """
                Kapıyı Kontrol Etmek vs. İçeri Girip Af Dilemek: LBYL, kapıyı açmadan önce 'Kapı var mı, kilitli mi, içeride biri var mı?' diye tek tek sorar; ama siz sorarken biri kapıyı kilitleyebilir. EAFP ise doğrudan kapıyı açmayı dener; kilitliyse özür dileyip anahtarı arar.
                """,
            TeknikMekanizma = """
                - Race Condition (Yarış Durumu): LBYL'de os.path.exists() kontrolü ile open() arasında geçen mikrosaniyede dosya silinebilir. EAFP işletim sistemi seviyesinde atomiktir ve daha hızlıdır.
                - İstisna Zincirleme (raise ... from e): Düşük seviyeli teknik hatayı (KeyError) iş mantığı hatasına (ConfigError) dönüştürürken kök nedeni kaybetmemeyi sağlar.
                - Log Seviyeleri: DEBUG < INFO < WARNING < ERROR < CRITICAL. logging.exception() tüm Traceback'i dosyaya kaydeder.
                """,
            PythonKodu = """
                import logging

                logging.basicConfig(
                    filename="sistem_hatalari.log",
                    level=logging.ERROR,
                    format="%(asctime)s - %(levelname)s - %(message)s"
                )

                class YetersizBakiyeHatasi(Exception):
                    def __init__(self, bakiye, tutar):
                        super().__init__(f"Bakiye yetersiz! Mevcut: {bakiye} TL, İstenen: {tutar} TL")

                def para_cek(bakiye, tutar):
                    if tutar <= 0:
                        raise ValueError("Çekilecek tutar pozitif olmalıdır.")
                    if tutar > bakiye:
                        raise YetersizBakiyeHatasi(bakiye, tutar)
                    return bakiye - tutar

                try:
                    para_cek(500, 1200)
                except YetersizBakiyeHatasi as e:
                    logging.exception("Ödeme işlemi reddedildi")
                    print(f"Kullanıcı Uyarısı: {e}")
                """,
            KodAciklamasi = """
                - Exception sınıfından miras alan YetersizBakiyeHatasi iş mantığına özel anlamlı hata yönetimi sağlar.
                - logging.exception() hatanın tarihini, saatini ve tam çağrı yığınını kalıcı dosyaya yazar.
                """,
            HatalarVeIpuclari = """
                - Kullanıcı girdisi doğrulamasında 'assert' kullanmayın: Python '-O' (Optimize) bayrağı ile çalıştırıldığında tüm assert satırları derleyici tarafından silinir. Kullanıcı girdileri için daima 'if ...: raise ValueError' kullanın.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Kalıcı Bellek Mimarisi, pathlib ve Context Manager (with)",
            Hafta = "Hafta 7",
            Kategori = "Dosya İşlemleri",
            KarmasiklikVeOzet = "pathlib & with open()",
            KavramsalAnlatim = """
                RAM (DRAM) veriyi mikroskobik kapasitörlerde tuttuğu için elektrik kesildiğinde veya program kapandığında tüm veriler uçar (volatile). SSD ve HDD ise veriyi manyetik veya elektron tuzaklarında kalıcı saklar. Dosya işlemleri, RAM'deki geçici veriyi işletim sistemi çekirdeği (Kernel) aracılığıyla kalıcı diske bayt akışı (Byte Stream) olarak kaydetme sürecidir.
                """,
            GercekHayatAnalojisi = """
                Çalışma Masası (RAM) ve Çelik Arşiv Dolabı (SSD/HDD): RAM geniş ve çok hızlı bir çalışma masasıdır ama mesai bitip elektrik kesilince masadaki her kağıt temizlenir. Dosya işlemleri, önemli belgeleri güvenli çelik arşiv dolabına kaldırmaktır. 'with' bloğu ise piknik bitince örtüyü otomatik toplayan akıllı sistemdir.
                """,
            TeknikMekanizma = """
                - Mutlak Yol (Absolute Path): C:\\Users\\Ali\\veri.txt gibi kökten başlar; başka bilgisayarda çalışmaz (taşınabilirliği bozar).
                - Göreli Yol (Relative Path): Mevcut çalışma dizinine (CWD) göre tarif edilir; taşınabilirdir.
                - pathlib.Path: Windows (\\) ve Linux/Mac (/) ayırıcı farklarını ortadan kaldıran nesne tabanlı modern yol yöneticisidir.
                - Context Manager (with): Arka planda __enter__ ve __exit__ metotlarını çalıştırarak blok içinde hata oluşsa bile dosyayı otomatik kapatır.
                """,
            PythonKodu = """
                from pathlib import Path
                import datetime

                # İşletim sisteminden bağımsız dinamik yol oluşturma
                klasor = Path.cwd() / "uygulama_loglari"
                klasor.mkdir(exist_ok=True)
                dosya_yolu = klasor / "sistem.log"

                zaman = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                # 'a' (append) modu eski veriyi silmeden sona ekler
                with open(dosya_yolu, "a", encoding="utf-8") as f:
                    f.write(f"[{zaman}] Uygulama başlatıldı.\\n")

                print("Dosya adı:", dosya_yolu.name, "| Uzantı:", dosya_yolu.suffix)
                print("Boyut (Bayt):", dosya_yolu.stat().st_size)
                """,
            KodAciklamasi = """
                - Path.cwd() / "uygulama_loglari" ifadesi operatör aşırı yüklemesiyle her işletim sisteminde geçerli yolu kurar.
                - with bloğu tamamlandığında f.close() otomatik olarak çağrılır ve işletim sistemi dosya kilidi serbest kalır.
                """,
            HatalarVeIpuclari = """
                - 'w' Modu Tehlikesi: Var olan bir dosyayı 'w' (Write) moduyla açtığınız an içeriği sıfırlanır (truncate). Üzerine eklemek için mutlaka 'a' (Append) kullanın.
                - close() unutulursa 'Too many open files' hatası oluşur veya Windows dosyayı kilitli tutar.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Büyük Dosya Okuma (Lazy Evaluation), Buffering ve UTF-8",
            Hafta = "Hafta 7",
            Kategori = "Veri Yönetimi & I/O",
            KarmasiklikVeOzet = "Lazy Evaluation & UTF-8",
            KavramsalAnlatim = """
                Dosya okumada kullanılan read(), readline() ve readlines() metotları bellek tüketimi açısından kritik farklar taşır. Çok büyük log ve veri dosyalarını RAM'i patlatmadan işlemek için Python'un dosya iterator yapısı (Lazy Evaluation) kullanılır. Ayrıca verilerin diske toplu yazılmasını sağlayan Buffer mekanizması ve evrensel UTF-8 karakter kodlaması veri bütünlüğünün temelidir.
                """,
            GercekHayatAnalojisi = """
                Çöp Kamyonu (Buffer) ve Rosetta Taşı (Encoding): Evdeki çöp kutusu (RAM Buffer) dolmadan belediyenin çöp kamyonunu (Disk I/O) çağırmazsınız; flush() ise dolmasını beklemeden kamyonu çağırmaktır. UTF-8 ile yazılmış bir dosyayı farklı bir kodlamayla açmak ise yanlış şifre çözücü gözlük takıp 'Mojibake' karakter çorbası görmektir.
                """,
            TeknikMekanizma = """
                - Lazy Evaluation (for satir in dosya): 100 GB'lık bir dosyayı bile RAM'de aynı anda yalnızca tek satır tutarak O(1) bellek maliyetiyle okur.
                - İmleç Kontrolü: tell() mevcut bayt konumunu verir; seek(0) imleci dosyanın en başına sarar.
                - Encoding & BOM: Windows varsayılan olarak cp1254 kullanırken Linux/Mac UTF-8 kullanır. Her zaman encoding='utf-8' belirtilmeli; Excel uyumluluğu için 'utf-8-sig' tercih edilmelidir.
                """,
            PythonKodu = """
                import csv

                # 1. Mülakat Standartı: Dev dosyaları bellek dostu satır satır filtreleme
                def hatalari_ayikla(kaynak_yol, hedef_yol):
                    bulunan = 0
                    with open(kaynak_yol, "r", encoding="utf-8") as f_in, \
                         open(hedef_yol, "w", encoding="utf-8") as f_out:
                        for satir in f_in:  # Lazy Evaluation (RAM'de tek satır tutar)
                            if "ERROR" in satir:
                                f_out.write(satir)
                                bulunan += 1
                    return bulunan

                # 2. CSV dosyalarını sütun adlarıyla güvenli okuma
                # with open("notlar.csv", newline="", encoding="utf-8") as f:
                #     for satir in csv.DictReader(f):
                #         print(satir["Ad"], satir["Not"])
                """,
            KodAciklamasi = """
                - 'for satir in f_in:' döngüsü readlines() gibi tüm dosyayı listeye doldurmaz; veriyi diskten yudum yudum çeker.
                - csv.DictReader ilk satırı başlık kabul ederek virgül içeren metinlerde sütun kaymasını önler.
                """,
            HatalarVeIpuclari = """
                - MemoryError Tuzağı: Büyük log veya veri dosyalarında dosya.read() ya da dosya.readlines() çağırmak tüm dosyayı RAM'e yükleyip programı çökertir.
                - Mojibake / UnicodeDecodeError: open() çağrısında encoding='utf-8' parametresini yazmayı unutmak farklı işletim sistemlerinde Türkçe karakterleri (ş, ğ, İ) bozar.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Yığın (Stack - LIFO) ve İki Yığınlı Tarayıcı Mimarisi",
            Hafta = "Hafta 8",
            Kategori = "Veri Yapıları",
            KarmasiklikVeOzet = "LIFO — Push/Pop O(1)",
            KavramsalAnlatim = """
                Yığın (Stack), 'Son Giren, İlk Çıkar' (Last-In, First-Out — LIFO) prensibiyle çalışan doğrusal bir veri yapısıdır. Eleman ekleme (Push) ve çıkarma (Pop) işlemleri yalnızca yığının en tepesinden yapılır. Tarayıcıların Geri/İleri butonları ve editörlerin Ctrl+Z (Geri Al) özelliği bu yapıyla çalışır.
                """,
            GercekHayatAnalojisi = """
                Krep Tabağı ve Şarjör: Üst üste pişen kreplerden ilk olarak en son pişen (en üstteki) krebi alırsınız. En alttaki krebe ulaşmak için üsttekileri sırayla kaldırmanız gerekir.
                """,
            TeknikMekanizma = """
                - Python listeleri sondan ekleme (append) ve sondan çıkarma (pop) işlemlerini O(1) sabit zamanda yapar.
                - İleri-Geri Tarayıcı Mimarisi: 'geri_yigini' ve 'ileri_yigini' adlı iki ayrı yığın kullanılır. Geri basıldığında aktif sayfa ileri yığınına atılır; yeni bir linke tıklandığında ileri yığını temizlenir (.clear()).
                """,
            PythonKodu = """
                class TarayiciGecmisi:
                    def __init__(self, ana_sayfa):
                        self.geri_yigini = [ana_sayfa]
                        self.ileri_yigini = []

                    def ziyaret_et(self, url):
                        self.geri_yigini.append(url)
                        self.ileri_yigini.clear()  # Yeni zaman çizelgesi!

                    def geri_git(self):
                        if len(self.geri_yigini) > 1:
                            self.ileri_yigini.append(self.geri_yigini.pop())
                        return self.geri_yigini[-1]

                    def ileri_git(self):
                        if self.ileri_yigini:
                            self.geri_yigini.append(self.ileri_yigini.pop())
                        return self.geri_yigini[-1]

                t = TarayiciGecmisi("google.com")
                t.ziyaret_et("github.com")
                t.ziyaret_et("python.org")
                print("Geri:", t.geri_git())   # github.com
                print("İleri:", t.ileri_git()) # python.org
                """,
            KodAciklamasi = """
                - append() Push işlemini, pop() Pop işlemini, [-1] ise en üstteki elemana silmeden bakmayı (Peek) sağlar.
                - Yeni sayfa ziyaret edildiğinde ileri_yigini.clear() çağrısı tutarlı durum yönetimini (State Management) garanti eder.
                """,
            HatalarVeIpuclari = """
                - IndexError: pop from empty list -> Yığın boşken pop() çağırmadan önce mutlaka 'if yigin:' kontrolü yapın.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Kuyruk (Queue - FIFO) ve collections.deque Performansı",
            Hafta = "Hafta 8",
            Kategori = "Veri Yapıları",
            KarmasiklikVeOzet = "FIFO — deque O(1) vs list O(n)",
            KavramsalAnlatim = """
                Kuyruk (Queue), 'İlk Giren, İlk Çıkar' (First-In, First-Out — FIFO) prensibine göre çalışır. Yeni elemanlar kuyruğun sonuna (rear) eklenir, işlemler kuyruğun başından (front) alınır. Yazıcı kuyrukları, çağrı merkezleri ve işletim sistemi görev zamanlayıcıları bu yapıyı kullanır.
                """,
            GercekHayatAnalojisi = """
                Sinema Bilet Gişesi: Sıraya ilk giren kişi bileti ilk alır. Eğer en öndeki kişi kalktığında arkadaki 1 milyon kişinin hepsi bir adım öne kaymak zorunda kalsaydı büyük bir zaman kaybı yaşanırdı.
                """,
            TeknikMekanizma = """
                - Standart Python listesinde 'liste.pop(0)' yapmak, kalan tüm elemanların bellekte bir sola kaydırılmasını gerektirir ve O(N) karmaşıklığındadır.
                - Çözüm: 'collections.deque' (Double-Ended Queue) çift yönlü bağlı liste benzeri bloklar kullanır; hem append() hem popleft() işlemlerini O(1) ışık hızında yapar.
                """,
            PythonKodu = """
                from collections import deque

                cagri_kuyrugu = deque()

                # Sıraya ekleme (Enqueue)
                cagri_kuyrugu.append("Müşteri #101")
                cagri_kuyrugu.append("Müşteri #102")
                cagri_kuyrugu.append("Müşteri #103")

                # Sıradan çıkarma (Dequeue - FIFO)
                while cagri_kuyrugu:
                    aktif = cagri_kuyrugu.popleft()
                    print(f"Temsilciye bağlandı: {aktif} | Bekleyen: {len(cagri_kuyrugu)}")
                """,
            KodAciklamasi = """
                - popleft() metodu kuyruğun en başındaki (ilk gelen) elemanı kaydırma maliyeti olmadan alır.
                - Döngüsel Kuyruk (Circular Queue) için alınan eleman tekrar sona append() edilebilir (müzik çalar repeat modu).
                """,
            HatalarVeIpuclari = """
                - Kuyruk yapısında popleft() yerine yanlışlıkla pop() kullanırsanız sistem Yığın (LIFO) gibi davranır ve ilk arayan müşteri sonsuza kadar bekler!
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Ağaç (Tree) Veri Yapısı ve Hiyerarşik Modelleme",
            Hafta = "Hafta 8",
            Kategori = "Veri Yapıları",
            KarmasiklikVeOzet = "Hiyerarşi & Recursive Traversal",
            KavramsalAnlatim = """
                Listeler, yığınlar ve kuyruklar doğrusal (lineer) yapılardır. Ancak klasör sistemleri, HTML DOM yapısı veya şirket organizasyon şemaları hiyerarşiktir ve Ağaç (Tree) veri yapısıyla modellenir. Bilgisayar bilimlerinde ağaçlar ters çizilir: Kök (Root) en tepededir, dallar aşağı doğru iner.
                """,
            GercekHayatAnalojisi = """
                Bilgisayar Klasör Sistemi ve Soy Ağacı: C:/ sürücüsü Kök (Root), içindeki klasörler Düğüm (Node), içinde başka alt klasör barındırmayan en uçtaki dosyalar ise Yaprak (Leaf) düğümlerdir.
                """,
            TeknikMekanizma = """
                - Root (Kök): Ebeveyni olmayan başlangıç düğümü.
                - Parent / Child (Ebeveyn / Çocuk): Düğümler arası üst-alt ilişkisi.
                - Leaf (Yaprak): Alt çocuğu olmayan en uç düğüm.
                - Ağaç derinliği önceden bilinmediği için ağaç üzerinde gezinme (traversal) işlemleri özyinelemeli (recursive) fonksiyonlarla yazılır.
                """,
            PythonKodu = """
                class DosyaDugumu:
                    def __init__(self, isim, dosya_mi=False):
                        self.isim = isim
                        self.dosya_mi = dosya_mi
                        self.cocuklar = []

                    def ekle(self, cocuk):
                        self.cocuklar.append(cocuk)

                    def agaci_yazdir(self, seviye=0):
                        girinti = "  " * seviye
                        simge = "[Dosya]" if self.dosya_mi else "[Klasör]"
                        print(f"{girinti}{simge} {self.isim}")
                        for cocuk in self.cocuklar:
                            cocuk.agaci_yazdir(seviye + 1)

                kok = DosyaDugumu("Bilgisayarım")
                belgeler = DosyaDugumu("Belgelerim")
                belgeler.ekle(DosyaDugumu("Vize_Odevi.pdf", True))
                kok.ekle(belgeler)
                kok.agaci_yazdir()
                """,
            KodAciklamasi = """
                - Her DosyaDugumu kendi çocuklarını bir listede tutar.
                - agaci_yazdir() metodu her alt klasör için kendini seviye + 1 parametresiyle tekrar çağırarak hiyerarşiyi girintili yazdırır.
                """,
            HatalarVeIpuclari = """
                - Ağaç yapısında bir çocuk düğümü yanlışlıkla kendi atasına (kök düğüme) bağlarsanız sonsuz döngü (graf çevrimi) oluşur.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Özyineleme (Recursion), Call Stack ve Stack Overflow",
            Hafta = "Hafta 9",
            Kategori = "Algoritmalar",
            KarmasiklikVeOzet = "Base Case + Recursive Step",
            KavramsalAnlatim = """
                Özyineleme (Recursion), bir fonksiyonun kendi kendini daha küçük bir alt problemle çağırmasıdır. Her özyinelemeli fonksiyon iki zorunlu parçadan oluşur: Durma koşulu olan 'Temel Durum' (Base Case) ve problemi küçülterek hedefe yaklaştıran 'Özyinelemeli Adım' (Recursive Step).
                """,
            GercekHayatAnalojisi = """
                Matruşka Bebekleri ve Karşılıklı Aynalar: En dıştaki Matruşka bebeğini açtığınızda içinden daha küçüğü çıkar; ta ki artık açılamayan en küçük tek parça bebeğe (Base Case) ulaşana kadar. Sonra en küçükten en büyüğe doğru sayılar toplanarak geri dönülür (Unwinding).
                """,
            TeknikMekanizma = """
                - Call Stack (Çağrı Yığını): Her fonksiyon çağrısı RAM'deki Stack alanında yeni bir 'Stack Frame' (parametreler + dönüş adresi) açar. Fonksiyonlar birbirinin yerine geçmez, üst üste biner.
                - Winding & Unwinding: Base Case'e kadar yığın dolar (Winding), Base Case değer döndürünce çerçeveler sırayla çözülüp kapanır (Unwinding).
                - Fibonacci Tuzağı: Saf recursive fib(n-1) + fib(n-2) aynı alt problemleri tekrar tekrar hesapladığı için O(2^n) üstel karmaşıklığa yol açar.
                """,
            PythonKodu = """
                def faktoriyel(n):
                    if n <= 1:  # Base Case (Fren mekanizması)
                        return 1
                    return n * faktoriyel(n - 1)  # Recursive Step

                def palindrom_mu(kelime):
                    if len(kelime) < 2:
                        return True
                    if kelime[0] != kelime[-1]:
                        return False
                    return palindrom_mu(kelime[1:-1])

                print("5! =", faktoriyel(5))
                print("KABAK palindrom mu?", palindrom_mu("KABAK"))
                """,
            KodAciklamasi = """
                - faktoriyel(5) -> 5 * faktoriyel(4) ... -> faktoriyel(1) = 1 zinciriyle geri dönerek 120 hesaplar.
                - palindrom_mu() soğan kabuğu soyar gibi baştaki ve sondaki harfleri eşleştirip ortadaki alt kelimeyi gönderir.
                """,
            HatalarVeIpuclari = """
                - RecursionError: maximum recursion depth exceeded -> Base Case unutulursa veya parametre Base Case'e yaklaşmazsa Stack belleği taşar (Stack Overflow) ve program çöker.
                - Python'da 'liste[1:]' dilimlemesi her adımda listenin kopyasını oluşturur; çok büyük listelerde indeks parametresi kullanmak daha bellek dostudur.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Doğrusal Arama (Linear) vs. İkili Arama (Binary Search)",
            Hafta = "Hafta 10",
            Kategori = "Arama Algoritmaları",
            KarmasiklikVeOzet = "O(n) vs. O(log n)",
            KavramsalAnlatim = """
                Doğrusal Arama (Linear Search), listeyi baştan sona tek tek kontrol eder; veri sırasız olsa bile çalışır ancak yavaş büyür O(n). İkili Arama (Binary Search) ise 'Böl ve Yönet' stratejisiyle her adımda arama alanını yarıya indirir O(log n); ancak verinin önceden kesinlikle sıralı (sorted) olmasını şart koşar.
                """,
            GercekHayatAnalojisi = """
                Çamaşır Sepeti vs. Telefon Rehberi: Karışık çamaşır sepetinde kırmızı çorabı bulmak için tek tek bakarsınız (Linear Search). A'dan Z'ye sıralı telefon rehberinde 'Yılmaz' soyadını ararken ise tam ortayı açar, 'K' harfini görünce sol yarıyı komple elersiniz (Binary Search).
                """,
            TeknikMekanizma = """
                - Logaritmik Güç: 1 milyar elemanlı sıralı bir dizide Doğrusal Arama 1 milyar adım atarken, İkili Arama en fazla 30 adımda (2^30 ≈ 1 milyar) sonuca ulaşır.
                - Donanım İçgörüsü: Çok küçük dizilerde (64-128 eleman) Doğrusal Arama, belleği ardışık okuduğu için CPU L1/L2 Cache dostudur ve atlama yapan İkili Aramadan pratikte hızlı olabilir.
                """,
            PythonKodu = """
                def ikili_arama(sirali_liste, hedef):
                    low = 0
                    high = len(sirali_liste) - 1
                    adim = 0

                    while low <= high:
                        adim += 1
                        mid = (low + high) // 2
                        if sirali_liste[mid] == hedef:
                            return mid, adim
                        elif sirali_liste[mid] < hedef:
                            low = mid + 1   # Sol yarıyı ele
                        else:
                            high = mid - 1  # Sağ yarıyı ele

                    return -1, adim

                sayilar = [3, 8, 15, 23, 42, 56, 78, 91, 105]
                indeks, deneme = ikili_arama(sayilar, 78)
                print(f"78 sayısı {indeks}. indekste, {deneme} adımda bulundu.")
                """,
            KodAciklamasi = """
                - 'mid = (low + high) // 2' tamsayı bölmesi ile ortadaki indeksi bulur.
                - Ortadaki eleman hedeften küçükse alt sınır 'mid + 1' yapılarak sol yarı tamamen elenir.
                """,
            HatalarVeIpuclari = """
                - Sonsuz Döngü Hatası: 'low = mid + 1' yerine yanlışlıkla 'low = mid' yazarsanız arama aralığı daralmaz ve while döngüsü sonsuza girer.
                - Sırasız listede İkili Arama çalıştırmak yanlış -1 sonucu döndürür.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Graf Teorisi (Graph Theory) ve Komşuluk Listeleri",
            Hafta = "Hafta 10",
            Kategori = "Graf Yapıları",
            KarmasiklikVeOzet = "G = (V, E) & Komşuluk Listesi",
            KavramsalAnlatim = """
                Doğrusal listeler ve hiyerarşik ağaçlar 'çoktan çoğa' (many-to-many) karmaşık ağ ilişkilerini modelleyemez. Graf Teorisi, varlıkları Düğüm (Vertex/Node) ve aralarındaki bağlantıları Kenar (Edge) olarak tanımlar. Sosyal ağlar, navigasyon rotaları ve internet bağlantıları graflarla modellenir.
                """,
            GercekHayatAnalojisi = """
                Königsberg Köprüleri (1736) ve Google Haritalar: Leonhard Euler, şehirdeki 7 köprüden birer kez geçme problemini kara parçalarını nokta (düğüm), köprüleri çizgi (kenar) yaparak çözdü. Navigasyonda şehirler düğüm, aralarındaki kilometre/süre değerleri ise ağırlıklı kenarlardır.
                """,
            TeknikMekanizma = """
                - Graf Türleri: Yönsüz (Facebook arkadaşlığı), Yönlü/Digraph (Instagram takibi, tek yönlü sokak), Ağırlıklı (Mesafe/maliyet içeren yollar).
                - Komşuluk Listesi (Adjacency List): Seyrek graflarda bellek dostudur; Python'da sözlük ve 'collections.defaultdict(list)' ile kurulur. Düğümün komşularına erişim O(1)'dir.
                """,
            PythonKodu = """
                from collections import defaultdict

                arkadasliklar = [
                    ("Ali", "Veli"), ("Ali", "Ayşe"),
                    ("Veli", "Cem"), ("Ayşe", "Fatma")
                ]

                graf = defaultdict(list)
                for k1, k2 in arkadasliklar:
                    graf[k1].append(k2)
                    graf[k2].append(k1)  # Yönsüz graf (karşılıklı bağ)

                def arkadas_oner(kisi, ag):
                    mevcut = set(ag[kisi])
                    oneriler = set()
                    for arkadas in mevcut:
                        for ikinci_derece in ag[arkadas]:
                            if ikinci_derece != kisi and ikinci_derece not in mevcut:
                                oneriler.add(ikinci_derece)
                    return list(oneriler)

                print("Ali için ortak arkadaş önerileri:", arkadas_oner("Ali", graf))
                """,
            KodAciklamasi = """
                - defaultdict(list) olmayan bir düğüm anahtarı çağrıldığında KeyError vermek yerine otomatik boş liste üretir.
                - 2. derece bağlantılar (arkadaşının arkadaşı) taranarak halihazırda arkadaş olmayan kişiler öneri listesine eklenir.
                """,
            HatalarVeIpuclari = """
                - Arkadaş önerisi algoritmasında 'ikinci_derece != kisi' kontrolünü unutursanız sistem kişiye kendisini arkadaş olarak önerir!
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Kabarcık (Bubble) ve Seçmeli (Selection) Sıralama",
            Hafta = "Hafta 8 & 11",
            Kategori = "Sıralama Algoritmaları",
            KarmasiklikVeOzet = "O(n²) — Stable vs. Unstable",
            KavramsalAnlatim = """
                Sıralama, arama hızını artıran kritik ön işlemdir. Kabarcık Sıralaması (Bubble Sort) bitişik elemanları kıyaslayıp takas ederek her turda en büyüğü sona taşır; kararlıdır (Stable) ve optimize edildiğinde neredeyse sıralı dizilerde O(n) performans verir. Seçmeli Sıralama (Selection Sort) ise her turda kalanların en küçüğünün indeksini bulur ve tek takasla başa alır.
                """,
            GercekHayatAnalojisi = """
                Okul Bahçesi Boy Sırası vs. Karpuz Tezgahı: Bubble Sort'ta öğrenciler sadece yanındakiyle konuşup uzun olan sağa geçer. Selection Sort'ta ise manav eline kırmızı bir etiket alır, tezgahı gezip en küçük karpuza etiketi yapıştırır ve tur sonunda sadece en baştaki karpuzla yer değiştirir.
                """,
            TeknikMekanizma = """
                - Bubble Sort Optimizasyonu: 'n - i - 1' sınırı sondaki yerleşmiş elemanları tekrar kontrol etmez; 'takas_yapildi' bayrağı (flag) hiç takas olmayan turda erken çıkış (break) sağlar.
                - Selection Sort Avantajı: Tur başına en fazla 1 takas yaptığı için yazma ömrü sınırlı EEPROM/Flash bellekleri az yıpratır; ancak eşit elemanların sırasını bozabildiği için Kararsızdır (Unstable).
                """,
            PythonKodu = """
                def kabarcik_optimize(liste):
                    n = len(liste)
                    for i in range(n):
                        takas_yapildi = False
                        for j in range(0, n - i - 1):
                            if liste[j] > liste[j + 1]:
                                liste[j], liste[j + 1] = liste[j + 1], liste[j]
                                takas_yapildi = True
                        if not takas_yapildi:
                            break
                    return liste

                def secmeli_siralama(liste):
                    n = len(liste)
                    for i in range(n - 1):
                        en_kucuk_idx = i
                        for j in range(i + 1, n):
                            if liste[j] < liste[en_kucuk_idx]:
                                en_kucuk_idx = j
                        if en_kucuk_idx != i:
                            liste[i], liste[en_kucuk_idx] = liste[en_kucuk_idx], liste[i]
                    return liste

                print("Bubble:", kabarcik_optimize([5, 1, 4, 2, 8]))
                print("Selection:", secmeli_siralama([20, 12, 10, 15, 2]))
                """,
            KodAciklamasi = """
                - Bubble Sort'ta tuple unpacking (a, b = b, a) geçici değişkene ihtiyaç duymadan Python VM'de takas yapar.
                - Selection Sort'ta en küçük değerin kendisi değil, indeksi ('en_kucuk_idx') tutulur; aksi halde takas anında elemanın yeri bilinemez.
                """,
            HatalarVeIpuclari = """
                - IndexError: Bubble Sort iç döngüsünde 'range(0, n)' yazarsanız j = n-1 olduğunda 'liste[j+1]' liste dışına taşar. Mutlaka 'n - i - 1' kullanın.
                """
        },
        new AnsiklopediMaddesi
        {
            Baslik = "Modüler Mimari, import Mekanizması ve __main__",
            Hafta = "Hafta 12",
            Kategori = "Kütüphane Yönetimi",
            KarmasiklikVeOzet = "sys.path, __pycache__ & __name__",
            KavramsalAnlatim = """
                Python'da .py uzantılı her dosya bir modüldür. Projeyi sabitler, veri katmanı, iş mantığı ve ana akış dosyalarına bölmek ekip çalışmasında Git çakışmalarını (Merge Conflict) önler ve bakımı kolaylaştırır. Bir modülün hem bağımsız çalıştırılabilmesi hem de güvenle import edilebilmesi için 'if __name__ == "__main__":' koruma bloğu kullanılır.
                """,
            GercekHayatAnalojisi = """
                Araba Fabrikası & Baş Aşçı Tarif Kitabı: Fabrikada motor, şasi ve elektronik ayrı departmanlardır; montaj hattı (main.py) parçaları birleştirir. Tarif kağıdını doğrudan pişiriyorsanız tadına bakarsınız (__main__); ama o tarifi başka bir yemek kitabına kopyalıyorsanız (import) test kodlarını çalıştırmazsınız.
                """,
            TeknikMekanizma = """
                - import Süreci: Python sırasıyla mevcut klasöre ve sys.path yollarına bakar, dosyayı Bytecode'a (.pyc) derleyip __pycache__ klasörüne kaydeder, kodu yukarıdan aşağı bir kez çalıştırır ve sys.modules önbelleğine alır.
                - Tarihsel Ders (Ariane 5 Faciası): 1996'da Ariane 4'ten bağlamı kontrol edilmeden kopyalanan modül, 64-bit sayıyı 16-bit tamsayıya sığdıramayınca (overflow) roket 37. saniyede infilak etmiştir.
                """,
            PythonKodu = """
                # dosya: geometri.py
                PI = 3.14159265359

                def daire_alani(yaricap):
                    return PI * (yaricap ** 2)

                # Bu dosya doğrudan çalıştırılırsa test çalışır,
                # başka dosyadan 'import geometri' yapılırsa çalışmaz:
                if __name__ == "__main__":
                    print("Modül testi -> Yarıçap 5 için alan:", daire_alani(5))
                """,
            KodAciklamasi = """
                - Dosya doğrudan çalıştırıldığında Python __name__ değişkenine "__main__" değerini atar.
                - Başka bir dosyadan import edildiğinde ise __name__ değişkeni dosya adı ("geometri") olur ve test bloğu atlanır.
                """,
            HatalarVeIpuclari = """
                - 'from math import *' kullanımından kaçının: Modüldeki tüm isimleri kontrolsüzce kodunuza döker ve mevcut fonksiyonlarınızla isim çakışmasına (Name Collision) yol açar. Bunun yerine 'import math' veya 'import numpy as np' kullanın.
                """
        }
    };
}